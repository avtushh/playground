﻿using UnityEngine;
using System.Collections;

public static class GameSettings {

	public static bool ShowAim = true;
	public static int startingStars = 3;
	public static bool reincartantBBTanObstacles = true;
	public static float timeToReincarnateBBTan = 30f;
}
